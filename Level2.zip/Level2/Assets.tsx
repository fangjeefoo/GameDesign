<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.2" name="Assets" tilewidth="16" tileheight="16" tilecount="322" columns="23">
 <image source="Legacy-Dungeon_V0.2_vacaroxa/Final/Assets/Assets.png" width="368" height="224"/>
 <tile id="15">
  <animation>
   <frame tileid="15" duration="200"/>
   <frame tileid="16" duration="200"/>
   <frame tileid="17" duration="200"/>
   <frame tileid="18" duration="200"/>
  </animation>
 </tile>
 <tile id="38">
  <animation>
   <frame tileid="38" duration="200"/>
   <frame tileid="39" duration="200"/>
   <frame tileid="40" duration="200"/>
   <frame tileid="41" duration="200"/>
  </animation>
 </tile>
 <tile id="143">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="6">
    <polygon points="0,0 2.72727,-2.72727 4.36364,0.545455 7.63636,-1.27273 15.8182,0.727273 15.6364,-6.18182 0,-6"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
